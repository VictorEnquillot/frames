(** {3 Inputbox_name_n_inputbase_name_by_localinput_context_inputbox_tag_provider_v} *)

(** {6 Documenting} *)

let documentation () = 
  [
   "Current : B:Inputbox_name_n_inputbase_name_by_localinput_context_inputbox_tag_provider_v";
   "Register : B:Inputbox_name_n_inputbase_name_by_localinput_context_inputbox_tag_register_v";
   "Needs : SDB1:Localinput_context_inputbox_symbol_v";
   "Needs : B:Localinput_context_inputbase_name_by_unit_provider_v";
   "Needed-by :"; 
   "What-is-it : the couple Inputbox_name_n_inputbase_name for Localinput_context_inputbox_tag";
   "Author : François Colonna 25 septembre 2016 at 20:02:51+02:00";
 ]
;;

let nam_mod = Management_v.current_module_name (documentation ()) ;;
 
(** {6 Building} *)
 
let build tag_lbo =
  let nam_lbo = Localinput_context_inputbox_tag_v.string_off tag_lbo in
  let nam_lba = Localinput_context_inputbase_name_by_unit_provider_v.provide () in
  (nam_lbo, nam_lba)
;;

(** {6 Storing} *)

let store tag_lbo result =
  let nam_fun = "store" in
  let pro_cpu = Management_v.entering_of_module_name_of_function_name nam_mod nam_fun in
  Inputbox_name_n_inputbase_name_by_localinput_context_inputbox_tag_register_v.store nam_mod tag_lbo result;
  Management_v.exiting_of_process_times_of_module_name_of_function_name pro_cpu nam_mod nam_fun;
;;

(** {6 Building and Storing} *)

let build_n_store tag_lbo =
  let result = build tag_lbo in
  store tag_lbo result;
  result
;;

(** {6 Retrieving} *)

let retrieve tag_lbo =
  let nam_fun = "retrieve" in
  let pro_cpu = Management_v.entering_of_module_name_of_function_name nam_mod nam_fun in
  let result = Inputbox_name_n_inputbase_name_by_localinput_context_inputbox_tag_register_v.retrieve nam_mod tag_lbo in
  Management_v.exiting_of_process_times_of_module_name_of_function_name pro_cpu nam_mod nam_fun;
  result
;;

(** {6 Providing without Trace} *)

let provide_without_trace tag_lbo =
  if Inputbox_name_n_inputbase_name_by_localinput_context_inputbox_tag_register_v.is_stored tag_lbo
  then retrieve tag_lbo
  else build_n_store tag_lbo
;;

(** {6 Providing} *)

let provide tag_lbo =
  let nam_fun = "provide" in
  let pro_cpu = Management_v.entering_of_module_name_of_function_name nam_mod nam_fun in
  let result = provide_without_trace tag_lbo in
  Management_v.exiting_of_process_times_of_module_name_of_function_name pro_cpu nam_mod nam_fun;
  result
;;

(* using template_provider_with_register_v.ml *)
(* done with do_provider_with_register.sh Inputbox_name_n_inputbase_name_by_localinput_context_inputbox_tag_provider_v.ml force on lundi 26 septembre 2016, 07:26:58 (UTC+0200) *)
