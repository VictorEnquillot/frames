(** {3 Localinput_tag_tree_by_inputbox_name_provider_v} *)

(** {6 Documenting} *)

let documentation () = 
  [
   "Current : B:Localinput_tag_tree_by_inputbox_name_provider_v";
   "Register : B:Localinput_tag_tree_by_inputbox_name_register_v";
   "Needs : B:Localinput_as_context_tag_quatuor_by_inputbox_name_provider_v";
   "Needs : B:Localinput_symbol_subtree_by_localinput_context_inputbox_tag_provider_v";
   "Needed-by :"; 
   "What-is-it : the Tree of Localinput_tag Rooted by Localinput Tag Quatuor";
   "How-is-it-done : getting Quatuor Localinput Tags";
   "How-is-it-done : adding it to Databox Rooted Localinput_symbol_subtree";
   "Abbreviation : dcs  = localinput_context_sector";
   "Abbreviation : dcd  = localinput_context_domain";
   "Abbreviation : dba  = localinput_context_inputbase";
   "Abbreviation : dbo  = localinput_context_inputbox";
   "Abbreviation : db1  = local";
   "Abbreviation : t    = tree";
   "Abbreviation : st   = subtree";
 ]
;;

(*         |-           Localinput_context_sector   -|          *)
(*         |                    / | \                |          *)
(*         |-           Localinput_context_domain   -| fixed    *)
(* Context |                    / | \                | trio     *)
(* Quatuor |-           Localinput_context_inputbase -|          *)
(*         |                    / | \                           *)
(*         |-           Localinput_context_inputbox  -| variable *)
(*         |                      |                             *)

let nam_mod = Management_v.current_module_name (documentation ()) ;;
 
(** {6 Building} *)

let build nam_lbo =
  let (tag_loi_lbo, tag_loi_lba, tag_loi_lcd, tag_loi_lcs) =
    Localinput_as_context_tag_quatuor_by_inputbox_name_provider_v.provide
      nam_lbo
  in

  let sym_loi_lbo_st =
    Localinput_symbol_subtree_by_inputbox_name_provider_v.provide
      nam_lbo
  in

  let soi_loi_lbo = Tag_v.sole_index_off_tag tag_loi_lbo in
  let soi_loi_lbo_st = 
    Sole_index_v.sole_index_tree_of_tree_of_root_sole_index 
      sym_loi_lbo_st 
      soi_loi_lbo 
  in
  let tag_loi_lbo_st = Tree_v.map2 Tag_v.make sym_loi_lbo_st soi_loi_lbo_st in
  let tag_loi_lba_st = Tree_v.make_of_node tag_loi_lba [tag_loi_lbo_st] in
  let tag_loi_lcd_st = Tree_v.make_of_node tag_loi_lcd [tag_loi_lba_st] in
  
  Tree_v.make_of_node tag_loi_lcs [tag_loi_lcd_st]
;;

(** {6 Storing} *)

let store nam_lbo result =
  let nam_fun = "store" in
  let pro_cpu = Management_v.entering_of_module_name_of_function_name nam_mod nam_fun in
  Localinput_tag_tree_by_inputbox_name_register_v.store nam_mod nam_lbo result;
  Management_v.exiting_of_process_times_of_module_name_of_function_name pro_cpu nam_mod nam_fun;
;;

(** {6 Building and Storing} *)

let build_n_store nam_lbo =
  let result = build nam_lbo in
  store nam_lbo result;
  result
;;

(** {6 Retrieving} *)

let retrieve nam_lbo =
  let nam_fun = "retrieve" in
  let pro_cpu = Management_v.entering_of_module_name_of_function_name nam_mod nam_fun in
  let result = Localinput_tag_tree_by_inputbox_name_register_v.retrieve nam_mod nam_lbo in
  Management_v.exiting_of_process_times_of_module_name_of_function_name pro_cpu nam_mod nam_fun;
  result
;;

(** {6 Providing without Trace} *)

let provide_without_trace nam_lbo =
  if Localinput_tag_tree_by_inputbox_name_register_v.is_stored nam_lbo
  then retrieve nam_lbo
  else build_n_store nam_lbo
;;

(** {6 Providing} *)

let provide nam_lbo =
  let nam_fun = "provide" in
  let pro_cpu = Management_v.entering_of_module_name_of_function_name nam_mod nam_fun in
  let result = provide_without_trace nam_lbo in
  Management_v.exiting_of_process_times_of_module_name_of_function_name pro_cpu nam_mod nam_fun;
  result
;;

(* using template_provider_with_register_v.ml *)
(* done with do_provider_with_register.sh Localinput_tag_tree_by_inputbox_name_provider_v.ml force on lundi 26 septembre 2016, 07:27:02 (UTC+0200) *)
