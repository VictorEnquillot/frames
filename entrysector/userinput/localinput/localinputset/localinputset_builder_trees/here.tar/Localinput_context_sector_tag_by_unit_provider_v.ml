(** {3 Localinput_context_sector_tag_by_unit_provider_v} *)

(** {6 Documenting} *)

let documentation () = 
  [
   "Current : B:Localinput_context_sector_tag_by_unit_provider_v";
   "Needs : B:Localinput_context_sector_name_by_unit_provider_v";
   "Needs : CONS:Context_sole_index_by_sector_name_provider_v";
   "Needs : SDB1:Localinput_context_sector_symbol_v";
   "Author : François Colonna 24 septembre 2016 at 13:39:55+02:00";
 ]
;;

let nam_mod = Management_v.current_module_name (documentation ()) ;;
 
(** {6 Building} *)

let build () =
  let nam_sec = Localinput_context_sector_name_by_unit_provider_v.provide () in
  let soi_sec = Context_sole_index_by_sector_name_provider_v.provide nam_sec in
  let sym_lcs = 
    Localinput_context_sector_symbol_v.localinput_context_sector_constructor 
      nam_sec 
  in
  Tag_v.make sym_lcs soi_sec
;;


(** {6 Providing} *)

let provide key =
  let nam_fun = "provide" in
  let pro_cpu = Management_v.entering_of_module_name_of_function_name nam_mod nam_fun in
  let result = build key in
  Management_v.exiting_of_process_times_of_module_name_of_function_name pro_cpu nam_mod nam_fun;
  result
;;

(* using template_provider_without_register_v.ml *)
(* done with do_provider_without_register.sh Localinput_context_sector_tag_by_unit_provider_v.ml force on lundi 26 septembre 2016, 07:27:05 (UTC+0200) *)
