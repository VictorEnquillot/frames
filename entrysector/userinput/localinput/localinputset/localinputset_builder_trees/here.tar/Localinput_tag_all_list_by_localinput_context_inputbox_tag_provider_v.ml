(** {3 Localinput_tag_all_list_by_localinput_context_inputbox_tag_provider_v} *)

(** {6 Documenting} *)

let documentation () = 
  [
   "Current : B:Localinput_tag_all_list_by_localinput_context_inputbox_tag_provider_v";
   "Register : B:Localinput_tag_all_list_by_localinput_context_inputbox_tag_register_v";
   "Needs : B:Localinput_tag_all_list_by_inputbox_name_provider_v";
   "Needed-by : B:";
   "What-is-it : the list of all Nodes of the Builder-tree (including Root))";
   "What-is-it : for Inputbase_name_n_inputbox_name with Localinput_tag as Root";
 ]
;;

let nam_mod = Management_v.current_module_name (documentation ()) ;;
 
(** {6 Building} *)

let build tag_lbo =
 let nam_lbo = Localinput_context_inputbox_tag_v.string_off tag_lbo in
  Localinput_tag_all_list_by_inputbox_name_provider_v.provide nam_lbo
;;

(** {6 Storing} *)

let store dbo tag_loi_l =
  let nam_fun = "store" in
  let pro_cpu = Management_v.entering_of_module_name_of_function_name nam_mod nam_fun in
  Localinput_tag_all_list_by_localinput_context_inputbox_tag_register_v.store nam_mod dbo tag_loi_l;
  Management_v.exiting_of_process_times_of_module_name_of_function_name pro_cpu nam_mod nam_fun;
;;

(** {6 Building and Storing} *)

let build_n_store dbo =
  let tag_loi_l = build dbo in
  store dbo tag_loi_l;
  tag_loi_l
;;

(** {6 Retrieving} *)

let retrieve dbo =
  let nam_fun = "retrieve" in
  let pro_cpu = Management_v.entering_of_module_name_of_function_name nam_mod nam_fun in
  let result = Localinput_tag_all_list_by_localinput_context_inputbox_tag_register_v.retrieve nam_mod dbo in
  Management_v.exiting_of_process_times_of_module_name_of_function_name pro_cpu nam_mod nam_fun;
  result
;;

(** {6 Providing without Trace} *)

let provide_without_trace dbo =
  if Localinput_tag_all_list_by_localinput_context_inputbox_tag_register_v.is_stored dbo
  then retrieve dbo
  else build_n_store dbo
;;

(** {6 Providing} *)

let provide dbo =
  let nam_fun = "provide" in
  let pro_cpu = Management_v.entering_of_module_name_of_function_name nam_mod nam_fun in
  let result = provide_without_trace dbo in
  Management_v.exiting_of_process_times_of_module_name_of_function_name pro_cpu nam_mod nam_fun;
  result
;;

(* using template_provider_tag_all_list_by_dddd_context_databox_tag_v.ml *)
(* done with do_provider_tag_all_list_by_dddd_context_databox_tag.sh force on lundi 26 septembre 2016, 07:27:07 (UTC+0200) *)
