(** {3 Localinput_as_fence_token_coordinates_kind_symbol_by_inputbox_name_provider_v} *)

(** {6 Documenting} *)

let documentation () = 
  [
   "Current : B:Localinput_as_fence_token_coordinates_kind_symbol_by_inputbox_name_provider_v";
   "Needs : B:Localinput_as_body_cluster_information_symbol_subtree_by_inputbox_name_provider_v";
   "Needed-by : B:";
   "What-is-it : the Db1user Coordinates_kind : cartesian, cylindrical, linear, planar, polar, spherical";
   "Abbreviation : dbo = localinput_context_inputbox";
 ]
;;

let nam_mod = Management_v.current_module_name (documentation ()) ;;
 
(** {6 Building} *)

let build nam_lbo =
  let sym_loi_dci_st = 
    Localinput_as_body_cluster_information_symbol_subtree_by_inputbox_name_provider_v.provide
      nam_lbo 
  in
  
  Tree_v.only_node_of_node_predicate_off_tree 
    Localinput_symbol_v.is_localinput_fence_token_coordinates_kind_symbol_off_localinput_symbol
    sym_loi_dci_st
;;


(** {6 Providing} *)

let provide key =
  let nam_fun = "provide" in
  let pro_cpu = Management_v.entering_of_module_name_of_function_name nam_mod nam_fun in
  let result = build key in
  Management_v.exiting_of_process_times_of_module_name_of_function_name pro_cpu nam_mod nam_fun;
  result
;;

(* done with do_provider_without_register.sh Localinput_as_fence_token_coordinates_kind_symbol_by_inputbox_name_provider_v.ml on samedi 21 mai 2016, 11:46:45 (UTC+0200) *)
