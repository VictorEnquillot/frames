(** {3 Localinput_context_inputbox_sole_index_by_any_sole_index_provider_v} *)

(** {6 Documenting} *)

let documentation () = 
  [
   "Current : B:Localinput_context_inputbox_sole_index_by_any_sole_index_provider_v";
   "Needs : B:Localinput_context_name_trio_by_unit_provider_v";
   "Needs : B:Context_sole_index_by_context_name_trio_provider_v";
   "What-is-it : the Databox Sole_index";
   "Author : François Colonna 25 septembre 2016 at 20:44:11+02:00";
 ]
;;

let nam_mod = Management_v.current_module_name (documentation ()) ;;
 
(** {6 Building} *)

let build soi_any =
  let nam_con_t = Localinput_context_name_trio_by_unit_provider_v.provide () in
  let soi_con = Context_sole_index_by_context_name_trio_provider_v.provide nam_con_t in
  let soi_qua = List_v.last_elements_of_int_of_list 4 soi_any in
  if List_v.are_included_of_small_list_of_big_list soi_con soi_qua
  then
    soi_qua
  else    
    Error_messages_v.print_fatal_error __LOC__ "build"
      (Format.sprintf "Current Sole_index >%s<@.   included Context_sole_index trio >%s<"
         (Sole_index_v.name soi_con) 
         (Sole_index_v.name soi_any)
      )
      "It is NOT"
      "Check"
;;


(** {6 Providing} *)

let provide key =
  let nam_fun = "provide" in
  let pro_cpu = Management_v.entering_of_module_name_of_function_name nam_mod nam_fun in
  let result = build key in
  Management_v.exiting_of_process_times_of_module_name_of_function_name pro_cpu nam_mod nam_fun;
  result
;;

(* using template_provider_without_register_v.ml *)
(* done with do_provider_without_register.sh Localinput_context_inputbox_sole_index_by_any_sole_index_provider_v.ml force on lundi 26 septembre 2016, 07:27:04 (UTC+0200) *)
