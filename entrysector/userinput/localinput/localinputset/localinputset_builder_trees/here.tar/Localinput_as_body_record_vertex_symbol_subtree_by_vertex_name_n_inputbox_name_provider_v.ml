(** {3 Localinput_as_body_record_vertex_symbol_subtree_by_vertex_name_n_inputbox_name_provider_v} *)

(** {6 Documenting} *)

let documentation () = 
  [
   "Current : B:Localinput_as_body_record_vertex_symbol_subtree_by_vertex_name_n_inputbox_name_provider_v";
   "Needs : B:Localinput_as_body_cluster_vertex_symbol_subtree_by_inputbox_name_provider_v";
   "Needed-by :"; 
   "What-is-it : the Subtree of Localinput_symbol Rooted by a record_ertex";
   "What-is-it : a Localinput_context_inputbox son is a ";
   "What-is-it : Localinput_field sons are Localinput_fence";
   "How-is-it-done : by using Parser";
   "Abbreviation : dbo  = databox";
   "Abbreviation : db1  = local";
   "Author : François Colonna 19 septembre 2016 at 11:55:32+02:00 no more lowercase";
 ]
;;


(*  <inputbox_name> ::= <cluster_vertex> <cluster_information>  *)

(*                                <inputbox_name>                      *)
(*                               /              \                     *)
(*                        <cluster_vertex>     <cluster_information>  *)
(*                        /              \                            *)
(*   <record_vertex>     <record_vertex> ....                         *)
(*                       /      |          \                          *)
(*                  vertex >vertex_name< <float_sequence>             *)

let nam_mod = Management_v.current_module_name (documentation ()) ;;

(** {6 Building} *)

let build (nam_ver, nam_lbo) =
  let sym_loi_dcv_st = 
    Localinput_as_body_cluster_vertex_symbol_subtree_by_inputbox_name_provider_v.provide 
      nam_lbo 
  in
  Tree_v.subtree_of_node_predicate_off_tree  
    (fun s ->
      (Localinput_symbol_v.is_localinput_body_record_vertex_constructor s)
	&&
      (Localinput_symbol_v.string_off s = nam_ver)
    )
    sym_loi_dcv_st
;;


(** {6 Providing} *)

let provide key =
  let nam_fun = "provide" in
  let pro_cpu = Management_v.entering_of_module_name_of_function_name nam_mod nam_fun in
  let result = build key in
  Management_v.exiting_of_process_times_of_module_name_of_function_name pro_cpu nam_mod nam_fun;
  result
;;

(* using template_provider_without_register_v.ml *)
(* done with do_provider_without_register.sh Localinput_as_body_cluster_vertex_symbol_subtree_by_inputbox_name_provider_v.ml force on lundi 26 septembre 2016, 07:27:03 (UTC+0200) *)
