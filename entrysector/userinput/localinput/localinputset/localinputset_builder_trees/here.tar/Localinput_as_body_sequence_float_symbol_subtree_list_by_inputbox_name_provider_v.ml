(** {3 Localinput_as_body_sequence_float_symbol_subtree_list_by_inputbox_name_provider_v} *)

(** {6 Documenting} *)

let documentation () = 
  [
   "Current : B:Localinput_as_body_sequence_float_symbol_subtree_list_by_inputbox_name_provider_v";
   "Register : B:Localinput_as_body_sequence_float_symbol_subtree_list_by_inputbox_name_register_v";
   "Needs : B:Localinput_symbol_subtree_by_inputbox_name_provider_v";
   "Needed-by : B:";
   "What-is-it : the Localinput_as_body_sequence_float symbol subtree list interfacing by Coordinate_tuple";
   "Abbreviation : dsf = localinput_body_sequence_float";
   "Abbreviation : dbo = localinput_context_inputbox";
 ]
;;

let nam_mod = Management_v.current_module_name (documentation ()) ;;
 
(** {6 Building} *)

let build nam_lbo =
  let sym_loi_st = 
    Localinput_symbol_subtree_by_inputbox_name_provider_v.provide
      nam_lbo 
  in
  
  Tree_v.subtree_list_of_node_predicate_off_tree 
    Localinput_symbol_v.is_localinput_body_sequence_float_symbol_off_localinput_symbol 
    sym_loi_st
;;

(** {6 Storing} *)

let store nam_lbo val_ =
  let nam_fun = "store" in
  let pro_cpu = Management_v.entering_of_module_name_of_function_name nam_mod nam_fun in
  Localinput_as_body_sequence_float_symbol_subtree_list_by_inputbox_name_register_v.store nam_mod nam_lbo val_;
  Management_v.exiting_of_process_times_of_module_name_of_function_name pro_cpu nam_mod nam_fun;
;;

(** {6 Building and Storing} *)

let build_n_store nam_lbo =
  let val_ = build nam_lbo in
  store nam_lbo val_;
  val_
;;

(** {6 Retrieving} *)

let retrieve nam_lbo =
  let nam_fun = "retrieve" in
  let pro_cpu = Management_v.entering_of_module_name_of_function_name nam_mod nam_fun in
  let result = Localinput_as_body_sequence_float_symbol_subtree_list_by_inputbox_name_register_v.retrieve nam_mod nam_lbo in
  Management_v.exiting_of_process_times_of_module_name_of_function_name pro_cpu nam_mod nam_fun;
  result
;;

(** {6 Providing without Trace} *)

let provide_without_trace nam_lbo =
  if Localinput_as_body_sequence_float_symbol_subtree_list_by_inputbox_name_register_v.is_stored nam_lbo
  then retrieve nam_lbo
  else build_n_store nam_lbo
;;

(** {6 Providing} *)

let provide nam_lbo =
  let nam_fun = "provide" in
  let pro_cpu = Management_v.entering_of_module_name_of_function_name nam_mod nam_fun in
  let result = provide_without_trace nam_lbo in
  Management_v.exiting_of_process_times_of_module_name_of_function_name pro_cpu nam_mod nam_fun;
  result
;;

(* done with do_provider_with_register.sh Localinput_as_body_sequence_float_symbol_subtree_list_by_inputbox_name_provider_v.ml on samedi 21 mai 2016, 11:46:39 (UTC+0200) *)
